#include "stm32f10x.h"
#include "bsp_led.h"
#include "bsp_TiMbase.h"

volatile uint32_t time = 0; // ms ��ʱ���� 

void  BASIC_TIM_IRQHandler (void)
{
	if ( TIM_GetITStatus( BASIC_TIM, TIM_IT_Update) != RESET ) 
	{	
		time++;
		TIM_ClearITPendingBit(BASIC_TIM , TIM_FLAG_Update);  		 
	}		 	
}

int main(void)
{
	/* led �˿����� */ 
	LED_GPIO_Config();
	
	BASIC_TIM_Init();
	
  while(1)
  {
    if ( time == 500 ) /* 500 * 1 ms = 0.5s ʱ�䵽 */
    {
      time = 0;
			LED1_TOGGLE; 			/* LED1 ȡ�� */     
    }        
  }
}
