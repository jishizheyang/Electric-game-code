#include "TIM.h"
#include "pid.h"
#include "led.h"


void Isr_Init()																							//�жϳ�ʼ��
{
	NVIC_InitTypeDef NVIC_InitStructure; 
	// TIM4_IRQChannel; 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel =TIM4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init (&NVIC_InitStructure); 
	// TIM3_IRQChannel; 
	NVIC_InitStructure.NVIC_IRQChannel =TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init (&NVIC_InitStructure);

}


//void Timer4_init(uint16_t freq ,uint8_t psc)	
//{	 
//	uint16_t TimerPerio;
//	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
//	RCC_APB1PeriphClockCmd (RCC_APB1Periph_TIM4,ENABLE);
//	
//	TimerPerio = (SystemCoreClock / psc / freq);
//	
//	TIM_TimeBaseStructure.TIM_Period = TimerPerio-1; 						//��������     
//	TIM_TimeBaseStructure.TIM_Prescaler =psc-1;									//��Ƶֵ   	    
//	TIM_TimeBaseStructure.TIM_ClockDivision = 0x0; 							//�ָ�ʱ��			
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //���ϼ���
//	TIM_DeInit(TIM4);
//	TIM_TimeBaseInit(TIM4, & TIM_TimeBaseStructure); 
//	TIM_Cmd(TIM4, ENABLE); 	 																		//ʹ�ܶ�ʱ��4

//	/*���¶�ʱ��4�жϳ�ʼ��*/
//	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE); 										//���ϼ�����������ж�

//}
  
void Timer3_init(uint16_t freq ,uint8_t psc)	
{
	uint16_t TimerPerio;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

	RCC_APB1PeriphClockCmd (RCC_APB1Periph_TIM3,ENABLE);
	TimerPerio = (SystemCoreClock / psc/ freq); 
	
	TIM_TimeBaseStructure.TIM_Period = TimerPerio-1; 						//��������    
	TIM_TimeBaseStructure.TIM_Prescaler =psc-1;									//��Ƶֵ   	    
	TIM_TimeBaseStructure.TIM_ClockDivision =TIM_CKD_DIV1; 			//�ָ�ʱ��			
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //���ϼ���
	TIM_DeInit(TIM3);
	TIM_TimeBaseInit(TIM3, & TIM_TimeBaseStructure); 
	TIM_Cmd(TIM3, ENABLE); 	 																		//ʹ�ܶ�ʱ��3

	/*���¶�ʱ��3�жϳ�ʼ��*/
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE); 										//���ϼ�����������ж�
}

/*===========================================================*/
uint16_t Channel1Pulse = 0;
uint16_t Channel2Pulse = 0;
uint16_t Channel3Pulse = 0;

void TIM8_PWM_Init(uint32_t freq ,uint8_t psc)          
{
	uint16_t TimerPerio;   //�Զ���װ��Ƶ��
	GPIO_InitTypeDef 					GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef 	TIM_TimeBaseStructure;      
	TIM_OCInitTypeDef 				TIM_OCInitStructure;          
	TIM_BDTRInitTypeDef 			TIM_BDTRInitStructure;      
	
	TimerPerio 		= (SystemCoreClock / psc / freq);
	Channel1Pulse = TimerPerio/2;
	Channel2Pulse = TimerPerio/2;
	Channel3Pulse = TimerPerio/2;
	/* TIM1,GPIOA,GPIOB*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);    
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE); 
	
	/*channel1,channel2 ,channel3 --> PC6 PC7 PC8*
	*channel1N,channel2N channel3N--> PA7 PB0 PB1*/
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_7;   
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP; 									 //�����������                                
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);           									 //��ʼ��GPIOA
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 														 //��ʼ��GPIOB
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;
	GPIO_Init(GPIOC,&GPIO_InitStructure); 														 //��ʼ��GPIOB
	/*  ???TIM1  */
	TIM_TimeBaseStructure.TIM_Period            = TimerPerio-1;   		 // ������װ������ֵ      
	TIM_TimeBaseStructure.TIM_Prescaler         = psc-1;        			 //����Ԥ��Ƶֵ          
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0;          				 //ʱ�ӷ�Ƶ          
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up;  //TIM���ϼ��� 
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;   								 //�ظ�����ж�                 
	TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);     							 //��ʼ����ʱ��                
	
	/* Channel_1   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;					//���ģʽ1������ֵС���趨ֵ��Ч
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;  //�Ƚ����ʹ��
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //PWM���������ʹ��
	TIM_OCInitStructure.TIM_Pulse        = Channel1Pulse;        		//ռ�ձ�����
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;  		//��Ч��ƽΪ��     
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;  		//�����෴         
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;   	//�������״̬
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;	//PWM�����������״̬      
	TIM_OC1Init(TIM8, &TIM_OCInitStructure); //��ʼ������TIM1 OC1
	/* Channel_2   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;             
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;    
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;     
	TIM_OCInitStructure.TIM_Pulse        = Channel2Pulse;               
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;         
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;        
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;         
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;     
	TIM_OC2Init(TIM8, &TIM_OCInitStructure);                            
	
	/* Channel_3      TIM_OCMode_PWM1ģʽ */  
//	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;            
//	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;      
//	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;     
//	TIM_OCInitStructure.TIM_Pulse        = Channel3Pulse;               
//	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;         
//	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;        
//	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;         
//	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;      
//	TIM_OC3Init(TIM8, &TIM_OCInitStructure);                            

	TIM_OC1PreloadConfig(TIM8, TIM_OCPreload_Enable);//ʹ��TIM1��CCR1�ϵ�Ԥװ�ؼĴ���
	TIM_OC2PreloadConfig(TIM8, TIM_OCPreload_Enable);                  
//	TIM_OC3PreloadConfig(TIM8, TIM_OCPreload_Enable);                   

	/*������ɲ����������*/
	TIM_BDTRInitStructure.TIM_OSSRState       = TIM_OSSRState_Enable;
	TIM_BDTRInitStructure.TIM_OSSIState       = TIM_OSSIState_Enable;
	TIM_BDTRInitStructure.TIM_LOCKLevel       = TIM_LOCKLevel_1;
	TIM_BDTRInitStructure.TIM_DeadTime        = 17;                   //����TIM_BDTR��DTG������ʱ��DTG[7:0]
	TIM_BDTRInitStructure.TIM_Break           = TIM_Break_Disable;
	TIM_BDTRInitStructure.TIM_BreakPolarity   = TIM_BreakPolarity_High;
	TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM8, &TIM_BDTRInitStructure);

	TIM_Cmd(TIM8, ENABLE);          //ʹ��TIM8                         
	TIM_CtrlPWMOutputs(TIM8,ENABLE); //PWM���ʹ��                                  
}



void TIM1_PWM_Init(uint32_t freq ,uint8_t psc)          
{
	uint16_t TimerPerio;   //�Զ���װ��Ƶ��
	GPIO_InitTypeDef 					GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef 	TIM_TimeBaseStructure;      
	TIM_OCInitTypeDef 				TIM_OCInitStructure;          
	TIM_BDTRInitTypeDef 			TIM_BDTRInitStructure;      
	
	TimerPerio 		= (SystemCoreClock / psc / freq);
	Channel1Pulse = TimerPerio/2;
	Channel2Pulse = TimerPerio/2;
	Channel3Pulse = TimerPerio/2;

	/* TIM1,GPIOA,GPIOB*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);    
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB , ENABLE); 
	
	/*channel1,channel2 ,channel3 --> PA8 PA9 PA10*
	*channel1N,channel2N channel3N--> PB13 PB14 PB15*/
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;   
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP; 									 //�����������                                
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);           									 //��ʼ��GPIOA
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 														 //��ʼ��GPIOB
	
	/*  ???TIM1  */
	TIM_TimeBaseStructure.TIM_Period            = TimerPerio-1;   		 // ������װ������ֵ      
	TIM_TimeBaseStructure.TIM_Prescaler         = psc-1;        			 //����Ԥ��Ƶֵ          
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0;          				 //ʱ�ӷ�Ƶ          
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up;  //TIM���ϼ��� 
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;   								 //�ظ�����ж�                 
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);     							 //��ʼ����ʱ��                
	
	/* Channel_1   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;					//���ģʽ1������ֵС���趨ֵ��Ч
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;  //�Ƚ����ʹ��
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //PWM���������ʹ��
	TIM_OCInitStructure.TIM_Pulse        = Channel1Pulse;        		//ռ�ձ�����
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;  		//��Ч��ƽΪ��     
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;  		//�����෴         
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;   	//�������״̬
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;	//PWM�����������״̬      
	TIM_OC1Init(TIM1, &TIM_OCInitStructure); //��ʼ������TIM1 OC1
	
	/* Channel_2   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_Pulse        = Channel2Pulse;               
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);                            
	                  
	/* Channel_3      TIM_OCMode_PWM1ģʽ */    
	TIM_OCInitStructure.TIM_Pulse        = Channel3Pulse;               
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);     

	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//ʹ��TIM1��CCR1�ϵ�Ԥװ�ؼĴ���
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);                  
 	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);                       

	/*������ɲ����������*/
	TIM_BDTRInitStructure.TIM_OSSRState       = TIM_OSSRState_Enable;
	TIM_BDTRInitStructure.TIM_OSSIState       = TIM_OSSIState_Enable;
	TIM_BDTRInitStructure.TIM_LOCKLevel       = TIM_LOCKLevel_1;
	TIM_BDTRInitStructure.TIM_DeadTime        = 17;                   //����TIM_BDTR��DTG������ʱ��DTG[7:0]
	TIM_BDTRInitStructure.TIM_Break           = TIM_Break_Disable;
	TIM_BDTRInitStructure.TIM_BreakPolarity   = TIM_BreakPolarity_High;
	TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM1, &TIM_BDTRInitStructure);

	TIM_Cmd(TIM1, ENABLE);          //ʹ��TIM1                         
	TIM_CtrlPWMOutputs(TIM1,ENABLE); //PWM���ʹ��                                  
}








//end of file

