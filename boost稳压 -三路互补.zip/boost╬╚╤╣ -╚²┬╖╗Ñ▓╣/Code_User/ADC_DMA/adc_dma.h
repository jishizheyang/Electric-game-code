#ifndef __ADC_DMA_H
#define __ADC_DMA_H
#include "stm32f10x.h"











void JX_ADC1_CH14ANDCH15_Init(void);
void JX_ADC_DMA_Init(void);
uint16_t  ADCValue(u8 list);
u16 Get_Adc_average(u8 ch,u8 times);











#endif
