#include "stm32f10x.h"
#include "delay.h"
#include "ili9341.h"
#include "led.h"
#include "stdio.h"
#include "TIM.h"
#include "adc_dma.h"
#include "pid.h"


/*  Founcational Prototype  */

uint8_t Metering = 0;						//�жϼƴ�
extern PIDTypeStruct pid;
extern float SetDuty;
extern u8 flagU,flagI;
extern float MeasureU,MeasureI,MeasureP;
float Resister;


int main(void)
{
	LED_Init_JX();
	delay_init(72);
	ILI9341_Iint();
	Timer3_init(1000,72);											
	Isr_Init();																//�жϳ�ʼ��
	TIM1_PWM_Init(20000,1);										
	
	while(1)
	{
		LCD_ShowString(0,0,"Set",24);
		LCD_ShowString(0,25,"hello",24);

	}
}





/*===========================================*/
/*user code*/


/*��ʱ��3�жϷ�����*/

 void TIM3_IRQHandler()
{					  
	if (TIM_GetFlagStatus(TIM3, TIM_IT_Update) == SET)
	{

		TIM_ClearFlag(TIM3, TIM_IT_Update);
	}
}


/*��ʱ��4�жϷ�����*/
void TIM4_IRQHandler()
{					    
	if (TIM_GetFlagStatus(TIM4, TIM_IT_Update) == SET)
	{
		
		//add your code
		TIM_ClearFlag(TIM4, TIM_IT_Update);
	}
}



