
#include "ili9341.h"
#include "ascii.h"
#include "delay.h"
#include <stdio.h>

uint16_t  FONT_COLOR=RED;
uint16_t  BACK_COLOR=BLACK;

void FSMC_Init(void)
{
    FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
    FSMC_NORSRAMTimingInitTypeDef  p; 
    
    
    p.FSMC_AddressSetupTime = 0x02;	 //��ַ����ʱ��
    p.FSMC_AddressHoldTime = 0x00;	 //��ַ����ʱ��
    p.FSMC_DataSetupTime = 0x05;		 //���ݽ���ʱ��
    p.FSMC_BusTurnAroundDuration = 0x00;
    p.FSMC_CLKDivision = 0x00;
    p.FSMC_DataLatency = 0x00;
    p.FSMC_AccessMode = FSMC_AccessMode_B;	 // һ��ʹ��ģʽB������LCD
    
    FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
    FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
    //FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
		FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_NOR;
    FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
    FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
    FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
    FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
    FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
    FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
    FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &p;
    FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &p;  
    
    FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); 
    
    /* ʹ�� FSMC Bank1_SRAM Bank */
    FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE);  
}

void TFT_GPIO_Init(void)
{
	/* ����һ��GPIO_IintTypeDef���͵ı��� */
	GPIO_InitTypeDef GPIO_InitStructure;
	/* ʹ��FSMCʱ��*/
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
	/* ʹ��FSMC��Ӧ��Ӧ�ܽ�ʱ��*/
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);
	/* ����FSMC���� */	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;// ����Ϊ50M
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_AF_PP;// ����Ϊ�����������ģʽ
	/* ѡ��GPIOD�ڵ����� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | 
	                              GPIO_Pin_5 | GPIO_Pin_7 | GPIO_Pin_8 | 
	                              GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | 
	                              GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	/* ѡ��GPIOE�ڵ����� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | 
	                              GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | 
	                              GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
  /* ���ú�FSMC���� */	
	FSMC_Init();
}



void ILI9341_Iint(void)     //��ʼ���ⶫ�� ֱ�Ӹ��ƺ���
{
	TFT_GPIO_Init();
	delay_ms(20);
	LCD_WR_REG(0xCF);  
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0xC1); 
	LCD_WR_DATA(0X30); 
	LCD_WR_REG(0xED);  
	LCD_WR_DATA(0x64); 
	LCD_WR_DATA(0x03); 
	LCD_WR_DATA(0X12); 
	LCD_WR_DATA(0X81); 
	LCD_WR_REG(0xE8);  
	LCD_WR_DATA(0x85); 
	LCD_WR_DATA(0x10); 
	LCD_WR_DATA(0x7A); 
	LCD_WR_REG(0xCB);  
	LCD_WR_DATA(0x39); 
	LCD_WR_DATA(0x2C); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x34); 
	LCD_WR_DATA(0x02); 
	LCD_WR_REG(0xF7);  
	LCD_WR_DATA(0x20); 
	LCD_WR_REG(0xEA);  
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00); 
	LCD_WR_REG(0xC0);    //Power control 
	LCD_WR_DATA(0x1B);   //VRH[5:0] 
	LCD_WR_REG(0xC1);    //Power control 
	LCD_WR_DATA(0x01);   //SAP[2:0];BT[3:0] 
	LCD_WR_REG(0xC5);    //VCM control 
	LCD_WR_DATA(0x30); 	 //3F
	LCD_WR_DATA(0x30); 	 //3C
	LCD_WR_REG(0xC7);    //VCM control2 
	LCD_WR_DATA(0XB7); 
	LCD_WR_REG(0x36);    // Memory Access Control 
	LCD_WR_DATA(0x08); 
	LCD_WR_REG(0x3A);   
	LCD_WR_DATA(0x55); 
	LCD_WR_REG(0xB1);   
	LCD_WR_DATA(0x00);   
	LCD_WR_DATA(0x1A); 
	LCD_WR_REG(0xB6);    // Display Function Control 
	LCD_WR_DATA(0x0A); 
	LCD_WR_DATA(0xA2); 
	LCD_WR_REG(0xF2);    // 3Gamma Function Disable 
	LCD_WR_DATA(0x00); 
	LCD_WR_REG(0x26);    //Gamma curve selected 
	LCD_WR_DATA(0x01); 
	LCD_WR_REG(0xE0);    //Set Gamma 
	LCD_WR_DATA(0x0F); 
	LCD_WR_DATA(0x2A); 
	LCD_WR_DATA(0x28); 
	LCD_WR_DATA(0x08); 
	LCD_WR_DATA(0x0E); 
	LCD_WR_DATA(0x08); 
	LCD_WR_DATA(0x54); 
	LCD_WR_DATA(0XA9); 
	LCD_WR_DATA(0x43); 
	LCD_WR_DATA(0x0A); 
	LCD_WR_DATA(0x0F); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00); 		 
	LCD_WR_REG(0XE1);    //Set Gamma 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x15); 
	LCD_WR_DATA(0x17); 
	LCD_WR_DATA(0x07); 
	LCD_WR_DATA(0x11); 
	LCD_WR_DATA(0x06); 
	LCD_WR_DATA(0x2B); 
	LCD_WR_DATA(0x56); 
	LCD_WR_DATA(0x3C); 
	LCD_WR_DATA(0x05); 
	LCD_WR_DATA(0x10); 
	LCD_WR_DATA(0x0F); 
	LCD_WR_DATA(0x3F); 
	LCD_WR_DATA(0x3F); 
	LCD_WR_DATA(0x0F); 
	LCD_WR_REG(0x2B); 
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x01);
	LCD_WR_DATA(0x3f);
	LCD_WR_REG(0x2A); 
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0xef);	 
	LCD_WR_REG(0x11); //Exit Sleep
	delay_ms(10);
	LCD_WR_REG(0x29); //display on	
	LCD_Clear(BLACK);
}

void LCD_XYRAM(uint16_t stx,uint16_t sty,uint16_t endx,uint16_t endy)
{
	LCD_WR_REG(0x2A);  //Column Address Set
	LCD_WR_DATA(stx>>8);    
	LCD_WR_DATA(stx&0xff); //2nd Parameter
	
	LCD_WR_DATA(endx>>8); 
	LCD_WR_DATA(endx&0xff);//4th Parameter

	LCD_WR_REG(0x2B);  // Page Address Set
	LCD_WR_DATA(sty>>8); 
	LCD_WR_DATA(sty&0xff);	
	LCD_WR_DATA(endy>>8); 
	LCD_WR_DATA(endy&0xff);
}

void LCD_Clear(uint16_t color)
{  
	unsigned int i,j;
	
	LCD_XYRAM(0,0,239,319);
  LCD_WR_REG(0x2C);
	for(i=0;i<320;i++)
	{
		for(j=0;j<240;j++)
		{
			LCD_WR_DATA(color);
		}
	}
}

/**********************************************/
/* �������ܣ���ʾ8*16����Ӣ���ַ�             */
/* ��ڲ�����x,y :�������	 	              	*/
/*           Char:��ĸ�����         	   	  	*/
/* ע    �⣺x,y��ȡֵҪ��240��320��Χ��      */
/**********************************************/
void LCD_ShowChar_0816(uint16_t x,uint16_t y,uint8_t Char)
{
	uint8_t temp,pos, t;
	LCD_XYRAM(x,y,x+7,y+15); // ����GRAM����
	LCD_WR_REG(0x002C);	  	 //ָ��RAM�Ĵ�����׼��д���ݵ�RAM
	Char -= ' ';
	for(pos=0;pos<16;pos++)
	{
		temp=ASCII_0816[Char][pos];		//ȡ����ģ�е�ǰ8���ֽ�
		for(t=0;t<8;t++)
		{                 
			if(temp&0x80)
				LCD_WR_DATA(FONT_COLOR);
			else 
				LCD_WR_DATA(BACK_COLOR);    
			temp<<=1; 
		}
		
	}
}

void LCD_ShowChar_1224(uint16_t x,uint16_t y,uint8_t Char) 
{
	uint8_t temp,pos, t;
	LCD_XYRAM(x,y,x+11,y+23); // ����GRAM����
	LCD_WR_REG(0x002C);	  	 //ָ��RAM�Ĵ�����׼��д���ݵ�RAM
	Char -= ' ';
	for(pos=0;pos<48;pos++)
	{
		temp=ASCII_1224[Char][pos];		//ȡ����ģ�е�ǰ8���ֽ�
		for(t=0;t<8;t++)
		{                 
			if(temp&0x80)
				LCD_WR_DATA(FONT_COLOR);
			else 
				LCD_WR_DATA(BACK_COLOR);    
			temp<<=1; 
		}
		temp=ASCII_1224[Char][++pos];//ȡ����ģ�е���һ���ֽڵ�ǰ4λ
		for(t=0;t<4;t++)
		{                 
			if(temp&0x80)
				LCD_WR_DATA(FONT_COLOR);
			else 
				LCD_WR_DATA(BACK_COLOR);    
			temp<<=1; 
		}
	}
}

void LCD_ShowString(uint16_t x,uint16_t y,char  *chr,uint8_t Fontsize)
{
	while(*chr != '\0')
	{
		if(Fontsize == 24)
		{
			LCD_ShowChar_1224(x,y,*chr++);
			x += 12;
		}
		else if(Fontsize == 16)
		{
			LCD_ShowChar_0816(x,y,*chr++);
			x += 8;
		}
		else 
		{
			LCD_ShowChar_1224(x,y,'N');
			LCD_ShowChar_1224(x+8,y,'F');
			break;
		}
	}
}

void ADC_Value_show(uint8_t x,uint16_t y,uint16_t adcx,uint8_t font)
{
	 float temp=0;
	 char  s[5];
	 temp=(float)adcx*(3.300/4095);// �����ѹֵ ��λv   ADCת������Ϊ12λ,������ֻ��4095���ɼ���ѹ���Ϊ3.3V
	 sprintf(s ,"%2.3f",temp );
    
	LCD_ShowString(x,y+font,s,font);
}



uint16_t TFT_Power(uint8_t m,uint8_t n)
{
	uint16_t retval = 1;
	while(n--)
	{
		retval *= m;
	}
	return retval ;
}
/*
	@brief		�������ʾ���ֵĳ���
	@param			Num:����ʾ������
	@retval			����
 */
uint8_t Num_length(uint32_t Num)//4294967295
{
	uint8_t retval = 1;
	while(Num /= 10)
		retval++;
		return retval;
}

void LCD_ShowNum(uint8_t x,uint16_t y,uint32_t num,uint8_t Fontsize)
{         	
	uint8_t t,temp,len;
	len = Num_length(num);	
	for(t=0;t<len;t++)
	{
		temp=(num/TFT_Power(10,len-t-1))%10;
		if(Fontsize == 24)
		{
		LCD_ShowChar_1224(x+12*t,y,temp+0X30); 
		}
		else if(Fontsize == 16)
		{
			LCD_ShowChar_0816(x+12*t,y,temp+0X30);	
		}
		else 
		{
			LCD_ShowChar_1224(x,y,'N');
			LCD_ShowChar_1224(x+8,y,'F');
			break;
		}
	}
} 

void LCD_DrawPoint(uint16_t x,uint16_t y,uint16_t color)
{
	LCD_XYRAM(x,y,x,y); // ����GRAM����
	LCD_WR_REG(0x002C);	//ָ��RAM�Ĵ�����׼��д���ݵ�RAM 	 
	LCD_WR_DATA(color);

}


//����
//stx,sty:�������
//endx,endy:�յ�����  
void LCD_DrawLine(uint16_t stx, uint16_t sty, uint16_t endx, uint16_t endy)
{
	uint16_t t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance,step_x,step_y,uRow,uCol; 

	delta_x=endx-stx; //������������ 
	delta_y=endy-sty; 
	uRow=stx; 
	uCol=sty; 
	if(delta_x>0)
		step_x=1; //���õ������� 
	else if(delta_x==0)
		step_x=0;//��ֱ�� 
	else 
		{
			step_x=-1;
			delta_x=-delta_x;
		} 
	if(delta_y>0)
		step_y=1; 
	else if(delta_y==0)
		step_y=0;//ˮƽ�� 
	else
		{
			step_y=-1;
			delta_y=-delta_y;
		} 
	if( delta_x>delta_y)
		distance=delta_x; //ѡȡ�������������� 
	else 
		distance=delta_y; 
	for(t=0;t<=distance+1;t++ )//������� 
	{  
		LCD_DrawPoint(uRow,uCol,RED );//���� 
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=step_x; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=step_y; 
		} 
	}  
}  









//end of file
