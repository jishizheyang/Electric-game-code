#include "stm32f10x.h"
#include "bsp_led.h"
#include "bsp_TiMbase.h"
#include "key.h"
#include "delay.h"
#include "ili9341.h"
#include "timer.h"
#include "adc1dma.h"
#include "tim1pwm.h"



#define CH 4
#define T 11

extern  uint16_t ADCConvertedValue[4];
	 uint16_t CCR1_Val=10000 ;
	 uint16_t CCR2_Val=10000 ;
	 uint16_t CCR3_Val=10000 ;
	 uint16_t CCR4_Val=10000 ;
	 uint16_t PrescalerValue=0;
	 

int main(void)
{
	delay_init(72);	
	ILI9341_Iint();
	JX_ADC1_CH14_Init();
	JX_ADC_DMA_Init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	KEY_Init();
	LED_GPIO_Config();
	BASIC_TIM_Init();
	TIM3_Int_Init(5999,7199);
	JX_TIM1_PWM_Init();
	
	LCD_ShowString(100,0,"HELLO",16);
	LCD_ShowString(0,24, "ADC1:",24);
	LCD_ShowString(0,48, "ADC2:",24);
	LCD_ShowString(0,72, "ADC3:",24);
	LCD_ShowString(0,96, "ADC4:",24);	
	LCD_ShowString(0,120,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,144,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,168,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,192,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,216,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,240,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,264,"PC4123456789012345678901234567890:",16);
	LCD_ShowString(0,288,"PC4123456789012345678901234567890:",16);
//	LCD_WriteString (  10,  50, LCD_COLOR_RED, LCD_COLOR_BLACK, (uint8_t *)"���ǵ���" );
			
			
	while(1)
  {
		ADC_Value_show(100,0, ADCConvertedValue[0],24);//PC3
		ADC_Value_show(100,24,ADCConvertedValue[1],24);//PC4
		ADC_Value_show(100,48,ADCConvertedValue[2],24);//PC5
		ADC_Value_show(100,72,ADCConvertedValue[3],24);//PC6
		//if((ADCConvertedValue[0]*(3.300/4095))>1)
			//GPIO_ResetBits(GPIOD,GPIO_Pin_12);

	//	else
			//GPIO_SetBits(GPIOD,GPIO_Pin_12);
	//		LCD_Showfloat(50,-12,averagevalue,24);
		
		if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)==0)	// ˵��key1���� ��ʱled1��
			{
				LED1_TOGGLE; 			/* LED1 ȡ�� */     
			}
			
        else if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)==0)	// ˵��key2���� ��ʱled2��
			{		
				LED2_TOGGLE; 			/* LED2 ȡ�� */     
			}
  
  }
}
