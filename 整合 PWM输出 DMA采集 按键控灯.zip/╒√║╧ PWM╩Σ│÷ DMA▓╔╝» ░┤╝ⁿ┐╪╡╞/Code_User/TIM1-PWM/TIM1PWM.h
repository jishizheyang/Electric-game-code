#ifndef __TIM1PWM_H
#define __TIM1PWM_H

#include "stm32f10x.h"

void JX_TIM1_PWM_Init(void);

#endif
