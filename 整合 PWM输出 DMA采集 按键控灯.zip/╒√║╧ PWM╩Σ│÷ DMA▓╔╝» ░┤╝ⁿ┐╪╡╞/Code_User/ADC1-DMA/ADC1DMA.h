#ifndef __ADC1DMA_H
#define __ADC1DMA_H 			   
#include "stm32f10x.h"


void JX_ADC_DMA_Init(void);
void JX_ADC1_CH14_Init(void);

#endif
