#include "stm32f10x.h"
#include "delay.h"
#include "ili9341.h"
#include "led.h"
#include "stdio.h"
#include "TIM.h"
#include "adc_dma.h"
#include "pid.h"


uint8_t Metering = 0;						//�жϼƴ�
extern PIDTypeStruct pid;
extern float SetDuty;
extern u8 flagU,flagI;
extern float MeasureU,MeasureI,MeasureP;
float Resister;

/*  Founcational Prototype  */


int main(void)
{
	LED_Init_JX();
	delay_init(72);
	ILI9341_Iint();
	JX_ADC_DMA_Init();												//ADC DMA�����ʼ��
	JX_ADC1_CH14ANDCH15_Init();								//ADC1 ͨ��14 15��ʼ��
	Timer3_init(1000,72);											//
	Isr_Init();																//�жϳ�ʼ��
	TIM8_PWM_Init(20000,1);										
	PID_Init();  
		
		flagU = 0;
		flagI = 1;
	while(1)
	{
		LCD_ShowString(0,0,"Set",24);
		LCD_ShowString(0,25,"Measure U",24);
		LCD_ShowString(0,75,"Measure I",24);
		LCD_ShowString(0,125,"Measure P",24);
		
		if (Metering >= 1)										//����ж��Ƿ����
		{
			MeasureU = Get_Adc_average(0,5)*(3.300/4095)*11.5;
			MeasureI = Get_Adc_average(1,5)*(3.300/4095)*5.4054-13.5135;
			Resister = MeasureU / MeasureI;
			Float_Num_show(0,250,Resister,16);
			if(flagU == 1)
			{
				if(Resister < 12.0)
				{
					flagU = 0;
					flagI = 1;
				}
			}
			if(flagI == 1)
			{
				if(Resister >= 12.0) 
				{
					flagU = 1;
					flagI = 0;
				}
			}
			PID_Calc();
			Metering = 0;
		}
		
		
		
		
		
	}
}





/*===========================================*/
/*user code*/


/*��ʱ��3�жϷ�����*/

 void TIM3_IRQHandler()
{					  
	if (TIM_GetFlagStatus(TIM3, TIM_IT_Update) == SET)
	{
		//add your code
		Metering++;
		TIM_ClearFlag(TIM3, TIM_IT_Update);
	}
}


/*��ʱ��4�жϷ�����*/
void TIM4_IRQHandler()
{					    
	if (TIM_GetFlagStatus(TIM4, TIM_IT_Update) == SET)
	{
		
		//add your code
		TIM_ClearFlag(TIM4, TIM_IT_Update);
	}
}



