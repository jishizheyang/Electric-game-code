#include "key.h"
#include "delay.h"
#include "ili9341.h"
#include "spwm.h"


void KEY_Initial(void)//
{
	/*
	k1->PD3
	k2->PD6

	*/
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOB Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	/* Configure PC13 6 in input push-Up mode */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
  GPIO_Init(GPIOC, &GPIO_InitStructure);
}
void Fcn_Key(void)
{
  	if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3) == RESET)//Increase RH
		{
			delay_ms(50);
			if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3)== RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOD, GPIO_Pin_3 ) == RESET);
				spwm.OutSinFreq++;
				SPWM_Init();
				if(spwm.OutSinFreq==100)spwm.OutSinFreq=50;
		  }

		}
		else if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == RESET)//Decrease RH
		{
			delay_ms(50);
			if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_13 ) == RESET);
				spwm.OutSinFreq++;
				SPWM_Out();
				if(spwm.OutSinFreq==100)spwm.OutSinFreq=50;
			}
		}	
		else 
			return ;
}

