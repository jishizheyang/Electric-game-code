#include "spwm.h"
#include "bsp_AdvanceTim.h" 
#include "math.h"
#include "ili9341.h"

#define K 399

void SPWM_Init(void)
{   
	uint16_t i;                                           //����
	spwm.InsquareFreq = K * spwm.OutSinFreq;              //���Ʒ�������Ƶ��
	spwm.Duty =(72000000/spwm.InsquareFreq/2);                   //ռ�ձ�
	for(i = 0; i < K; i++)
	{
		spwm.table_399_a[i] = spwm.Duty *(1+sin((float)i/K*6.28));
	}
	spwm.SinTab_i = 0;
	BASIC_TIM_Mode_Config(spwm.InsquareFreq,1);
	ADVANCE_TIM_GPIO_Config(spwm.InsquareFreq,1); 
	
	
	spwm.InsquareFreq = K * spwm.OutSinFreq;              //���Ʒ�������Ƶ��
	spwm.Duty =(72000000/spwm.InsquareFreq/2);                   //ռ�ձ�
	for(i = 0; i < K; i++)
	{
		spwm.table_399_b[i] = spwm.Duty *(1+sin(((float)i/K*6.28)+1.05));
	}
	spwm.SinTab_i = 0;
	BASIC_TIM_Mode_Config(spwm.InsquareFreq,1);
	ADVANCE_TIM_GPIO_Config(spwm.InsquareFreq,1); 
	
	
	spwm.InsquareFreq = K * spwm.OutSinFreq;              //���Ʒ�������Ƶ��
	spwm.Duty =(72000000/spwm.InsquareFreq/2);                   //ռ�ձ�
	for(i = 0; i < K; i++)
	{
		spwm.table_399_c[i] = spwm.Duty *(1+sin(((float)i/K*6.28)+2.10));
	}
	spwm.SinTab_i = 0;
	BASIC_TIM_Mode_Config(spwm.InsquareFreq,1);
	ADVANCE_TIM_GPIO_Config(spwm.InsquareFreq,1); 
}



void SPWM_Out(void)
{
	TIM1 -> CCR1 = spwm.table_399_a[spwm.SinTab_i];
  TIM1 -> CCR2 = spwm.table_399_b[spwm.SinTab_i]; 
  TIM1 -> CCR3 = spwm.table_399_c[spwm.SinTab_i]; 	
	spwm.SinTab_i++;
	if(spwm.SinTab_i == K )                       //�ж��Ƿ���һ������
	{
		spwm.SinTab_i = 0;
	}
}

