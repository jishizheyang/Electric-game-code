/* -----------------------------------------------------------------------
		TIM1���ã�����4����ͬռ�ձȵ�PWM�ź� ��Щ���ε�Ƶ��Ϊ36KHz
		
    TIM1 Frequency = TIM1 counter clock/(ARR + 1) = 1 MHz / 20000(TIM_Period) = 50Hz
		
    TIM1 Channel1 duty cycle = (TIM1_CCR1/ TIM1_ARR)* 100 = 77%
    TIM1 Channel2 duty cycle = (TIM1_CCR2/ TIM1_ARR)* 100 = 66%
    TIM1 Channel3 duty cycle = (TIM1_CCR3/ TIM1_ARR)* 100 = 33%
    TIM1 Channel4 duty cycle = (TIM1_CCR4/ TIM1_ARR)* 100 = 22%
  ----------------------------------------------------------------------- */



#include "TIM1PWM.h"
 
  extern uint16_t CCR1_Val ;
	extern uint16_t CCR2_Val ;
	extern uint16_t CCR3_Val ;
	extern uint16_t CCR4_Val ;
	extern uint16_t PrescalerValue;
	uint16_t Channel1Pulse = 0;
	uint16_t Channel2Pulse = 0;
	uint16_t Channel3Pulse = 0;

void TIM1_PWM_Init(uint32_t freq ,uint8_t psc)  
{
uint16_t TimerPerio;   //�Զ���װ��Ƶ��
	GPIO_InitTypeDef 					GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef 	TIM_TimeBaseStructure;      
	TIM_OCInitTypeDef 				TIM_OCInitStructure;          
	TIM_BDTRInitTypeDef 			TIM_BDTRInitStructure;      
	
	TimerPerio 		= (SystemCoreClock / psc / freq);
	Channel1Pulse = TimerPerio/2;
	Channel2Pulse = TimerPerio/2;
	Channel3Pulse = TimerPerio/2;

	/* TIM1,GPIOA,GPIOB*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);    
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB , ENABLE); 
	
	/*channel1,channel2 ,channel3 --> PA8 PA9 PA10*
	*channel1N,channel2N channel3N--> PB13 PB14 PB15*/
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;   
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP; 									 //�����������                                
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);           									 //��ʼ��GPIOA
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 														 //��ʼ��GPIOB
	
	/*  ???TIM1  */
	TIM_TimeBaseStructure.TIM_Period            = TimerPerio-1;   		 // ������װ������ֵ      
	TIM_TimeBaseStructure.TIM_Prescaler         = psc-1;        			 //����Ԥ��Ƶֵ          
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0;          				 //ʱ�ӷ�Ƶ          
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up;  //TIM���ϼ��� 
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;   								 //�ظ�����ж�                 
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);     							 //��ʼ����ʱ��                
	
	/* Channel_1   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;					//���ģʽ1������ֵС���趨ֵ��Ч
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;  //�Ƚ����ʹ��
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //PWM���������ʹ��
	TIM_OCInitStructure.TIM_Pulse        = Channel1Pulse;        		//ռ�ձ�����
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;  		//��Ч��ƽΪ��     
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;  		//�����෴         
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;   	//�������״̬
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;	//PWM�����������״̬      
	TIM_OC1Init(TIM1, &TIM_OCInitStructure); //��ʼ������TIM1 OC1
	
	/* Channel_2   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_Pulse        = Channel2Pulse;               
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);                            
	                  
	/* Channel_3      TIM_OCMode_PWM1ģʽ */    
	TIM_OCInitStructure.TIM_Pulse        = Channel3Pulse;               
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);     

	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//ʹ��TIM1��CCR1�ϵ�Ԥװ�ؼĴ���
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);                  
 	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);                       

	/*������ɲ����������*/
	TIM_BDTRInitStructure.TIM_OSSRState       = TIM_OSSRState_Enable;
	TIM_BDTRInitStructure.TIM_OSSIState       = TIM_OSSIState_Enable;
	TIM_BDTRInitStructure.TIM_LOCKLevel       = TIM_LOCKLevel_1;
	TIM_BDTRInitStructure.TIM_DeadTime        = 17;                   //����TIM_BDTR��DTG������ʱ��DTG[7:0]
	TIM_BDTRInitStructure.TIM_Break           = TIM_Break_Disable;
	TIM_BDTRInitStructure.TIM_BreakPolarity   = TIM_BreakPolarity_High;
	TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM1, &TIM_BDTRInitStructure);

	TIM_Cmd(TIM1, ENABLE);          //ʹ��TIM1                         
	TIM_CtrlPWMOutputs(TIM1,ENABLE); //PWM���ʹ��       
}

void JX_TIM2_PWM_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	/* ����TIM2ʱ�� */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

  /* ����GPIOAʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	/* TIM1ͨ��1 2 3 4���� �ֱ���PA8 PA9  PA10 PA11 PB1 PB2 */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* ����Ԥ��Ƶֵ */
  PrescalerValue = 71;
  /* ���ö�ʱ�� */
  TIM_TimeBaseStructure.TIM_Period = 20000;
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  /* ͨ��1���� */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR1_Val;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC1Init(TIM2, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);

  /* ͨ��2���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC2Init(TIM2, &TIM_OCInitStructure);
  TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);

  /* ͨ��3���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;

  TIM_OCInitStructure.TIM_Pulse = CCR3_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC3Init(TIM2, &TIM_OCInitStructure);
  TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);

  /* ͨ��4���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR4_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  	
  TIM_OC4Init(TIM2, &TIM_OCInitStructure);
  TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable);
	
	
  TIM_ARRPreloadConfig(TIM2, ENABLE);
	
  /* ����TIM2���� */
  TIM_Cmd(TIM2, ENABLE);
	TIM_CtrlPWMOutputs(TIM2, ENABLE);
}

void JX_TIM3_PWM_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	/* ����TIM3ʱ�� */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

  /* ����GPIOA��GPIOBʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB , ENABLE);
	
	/* TIM1ͨ��1 2 3 4���� �ֱ���PA8 PA9  PA10 PA11 PB1 PB2 */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* ����Ԥ��Ƶֵ */
  PrescalerValue = 71;
  /* ���ö�ʱ�� */
  TIM_TimeBaseStructure.TIM_Period = 20000;
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  /* ͨ��1���� */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR1_Val;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC1Init(TIM3, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* ͨ��2���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC2Init(TIM3, &TIM_OCInitStructure);
  TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* ͨ��3���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR3_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC3Init(TIM3, &TIM_OCInitStructure);
  TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

  /* ͨ��4���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR4_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC4Init(TIM3, &TIM_OCInitStructure);
  TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);
	
  TIM_ARRPreloadConfig(TIM3, ENABLE);
	
  /* ����TIM1���� */
  TIM_Cmd(TIM3, ENABLE);
	TIM_CtrlPWMOutputs(TIM3, ENABLE);
}

void JX_TIM4_PWM_Init(void)
{
	
	GPIO_InitTypeDef GPIO_InitStructure;

	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	/* ����TIM4ʱ�� */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

  /* ����GPIOAʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	/* TIM1ͨ��1 2 3 4���� �ֱ���PA8 PA9  PA10 PA11 PB1 PB2 */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* ����Ԥ��Ƶֵ */
  PrescalerValue = 71;
  /* ���ö�ʱ�� */
  TIM_TimeBaseStructure.TIM_Period = 20000;
  TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

  /* ͨ��1���� */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR1_Val;
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC1Init(TIM4, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);

  /* ͨ��2���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR2_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC2Init(TIM4, &TIM_OCInitStructure);
  TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);

  /* ͨ��3���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;

  TIM_OCInitStructure.TIM_Pulse = CCR3_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC3Init(TIM4, &TIM_OCInitStructure);
  TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);

  /* ͨ��4���� */
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = CCR4_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
  TIM_OC4Init(TIM4, &TIM_OCInitStructure);
  TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
	
  TIM_ARRPreloadConfig(TIM4, ENABLE);
	
  /* ����TIM1���� */
  TIM_Cmd(TIM4, ENABLE);
	TIM_CtrlPWMOutputs(TIM4, ENABLE);
}

