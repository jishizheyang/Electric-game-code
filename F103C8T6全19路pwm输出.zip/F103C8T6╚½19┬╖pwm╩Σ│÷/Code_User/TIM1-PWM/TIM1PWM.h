#ifndef __TIM1PWM_H
#define __TIM1PWM_H

#include "stm32f10x.h"
void TIM1_PWM_Init(uint32_t freq ,uint8_t psc);

void JX_TIM2_PWM_Init(void);
void JX_TIM3_PWM_Init(void);
void JX_TIM4_PWM_Init(void);
#endif
