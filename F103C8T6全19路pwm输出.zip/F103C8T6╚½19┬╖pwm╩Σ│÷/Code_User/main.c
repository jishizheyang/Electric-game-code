#include "stm32f10x.h"
#include "delay.h"
#include "TIM1PWM.h"


extern  uint16_t ADCConvertedValue[1];
	 uint16_t CCR1_Val=10000 ;
	 uint16_t CCR2_Val=10000 ;
	 uint16_t CCR3_Val=10000 ;
	 uint16_t CCR4_Val=10000 ;
	 uint16_t PrescalerValue=0;
int main(void)
{
	delay_init(72);
	TIM1_PWM_Init(20000,1);		
//  JX_TIM2_PWM_Init();
//  JX_TIM3_PWM_Init();
//  JX_TIM4_PWM_Init();

}

