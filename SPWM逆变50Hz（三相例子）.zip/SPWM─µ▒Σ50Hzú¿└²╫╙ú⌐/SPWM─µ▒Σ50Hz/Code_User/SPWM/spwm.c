#include "spwm.h"
#include "TIM.h"
#include "math.h"
#include "ili9341.h"

#define K 399

void SPWM_Init(void)
{   
	uint16_t i;                                           //����
	spwm.InsquareFreq = K * spwm.OutSinFreq;              //���Ʒ�������Ƶ��
	spwm.Duty = 72000000/spwm.InsquareFreq/2;             //��������
	for(i = 0; i < K; i++)
	{
		spwm.table_399_a[i] = spwm.Duty *(1+sin((float)i/K*6.28-2.094395));
		spwm.table_399_b[i] = spwm.Duty *(1+sin((float)i/K*6.28));
		spwm.table_399_c[i] = spwm.Duty *(1+sin((float)i/K*6.28+2.094395));
	}
	spwm.SinTab_i = 0;
	TIM1_PWM_Init(spwm.InsquareFreq,1);          	        //pwm����Ƶ��spwm.OutSinFreq(30-100Hz)
	Timer5_init(spwm.InsquareFreq,1);
}



void SPWM_Out(void)
{
	TIM1 -> CCR1 = spwm.table_399_a[spwm.SinTab_i];
  TIM1 -> CCR2 = spwm.table_399_b[spwm.SinTab_i];  
  TIM1 -> CCR3 = spwm.table_399_c[spwm.SinTab_i];  
	spwm.SinTab_i++;
	if(spwm.SinTab_i == K )                       //�ж��Ƿ���һ������
	{
		spwm.SinTab_i = 0;
	}
}

