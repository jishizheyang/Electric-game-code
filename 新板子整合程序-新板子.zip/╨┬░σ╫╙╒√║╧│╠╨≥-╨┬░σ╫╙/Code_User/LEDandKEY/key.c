#include "key.h"
#include "delay.h"
#include "led.h"
#include "ili9341.h"
#include "SPWM.h"
void KEY_Initial(void)
{
	/*
	k1->PE0
	k2->PE1
	k3->PE2
	k4->PE3
	*/
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOB Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

  /* Configure PE0 1 2 3  in input pushup mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
	
}
void Fcn_Key(void)
{
	if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_0) == RESET)//K1
		{
			delay_ms(2);
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_0) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOE, GPIO_Pin_0 ) == RESET);
				GPIO_ResetBits(GPIOE,GPIO_Pin_4);						  	// LED1��
				
//		   	spwm.OutSinFreq += spwm.FreqStep;                                       //��Ƶ��
//		  	if(spwm.OutSinFreq>900)
//		  	{
//		  		spwm.OutSinFreq = 900;
//		  	}
//		    	SPWM_Init();
			}
			
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_1) == RESET)//K2
		{
			delay_ms(2);
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_1) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOE, GPIO_Pin_1) == RESET);
				GPIO_SetBits(GPIOE,GPIO_Pin_4);						  	// LED1��
			
//			  spwm.OutSinFreq -= spwm.FreqStep;     
//			  if(spwm.OutSinFreq<5)
//			  {
//				  spwm.OutSinFreq = 5;
//			  }
//			  SPWM_Init();
			}
		}	
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == RESET)//K3
		{
			delay_ms(2);
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOE, GPIO_Pin_2 ) == RESET);
				GPIO_ResetBits(GPIOE,GPIO_Pin_5);						  	// LED2��
				
			}
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == RESET)//K4
		{
			delay_ms(2);
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOE, GPIO_Pin_3 ) == RESET);
				GPIO_SetBits(GPIOE,GPIO_Pin_5);						  	// LED2��
		
			}
		}
		else
			return ;
}

void delay_ns(u32 ntimer)
{
	u32 i = (uint32_t)ntimer/13.9;
	while(i--);
}

