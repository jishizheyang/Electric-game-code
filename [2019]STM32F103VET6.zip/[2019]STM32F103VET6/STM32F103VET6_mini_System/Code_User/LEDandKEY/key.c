#include "key.h"
#include "delay.h"
#include "led.h"
#include "ili9341.h"
#include "ADC.h"
void KEY_Initial(void)//
{
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOB Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE);

  /* Configure PA2 3 in input pushup mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	  /* Configure PB8 in input pushup mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
		/* Configure PC13 in input push-Up mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* Configure PD3 in input push-Up mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
  GPIO_Init(GPIOD, &GPIO_InitStructure);
}
void Fcn_Key(void)
{
	 if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == RESET)       //KEY1
		{
			delay_ms(2);
			if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_13 ) == RESET);
//			  LCD_Clear_acs(0, 80, 240, 100, BLACK);
				GPIO_TogglePin(GPIOB,GPIO_Pin_5);
//				GPIO_TogglePin(GPIOD,GPIO_Pin_12);
			}
		}	
		else if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3) == RESET)  //KEY2
		{
			delay_ms(2);
		 if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_3) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOD, GPIO_Pin_3 ) == RESET);
//				GPIO_TogglePin(GPIOB,GPIO_Pin_5);
				GPIO_TogglePin(GPIOD,GPIO_Pin_12);
			}
		}
		else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == RESET)  //KEY3
		{
			delay_ms(2);
		 if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == RESET)
			{
				while(GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_8) == RESET);
				GPIO_TogglePin(GPIOB,GPIO_Pin_5);
//				GPIO_TogglePin(GPIOD,GPIO_Pin_12);
			}
		}
		else if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == RESET)  //KEY4
		{
			delay_ms(2);
		 if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == RESET)
			{
				while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == RESET);
//				GPIO_TogglePin(GPIOB,GPIO_Pin_5);
				GPIO_TogglePin(GPIOD,GPIO_Pin_12);
			}
		}
		else if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == RESET)  //KEY5
		{
			delay_ms(2);
		 if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == RESET)
			{
				while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == RESET);
				GPIO_TogglePin(GPIOB,GPIO_Pin_5);
				GPIO_TogglePin(GPIOD,GPIO_Pin_12);
			}
		}
		else 
			return ;
}

