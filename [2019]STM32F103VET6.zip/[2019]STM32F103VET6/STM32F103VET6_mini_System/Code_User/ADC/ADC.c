#include "adc.h"
#define ADC1_DR_Address    ((uint32_t)0x4001244C)



/**********************************************/
/* �������ܣ�DMA��ʼ������										*/
/* ��ڲ�������	 	      											*/
/**********************************************/
void ADC_DMA_Init(void)
{
	DMA_InitTypeDef DMA_InitStructure;
	
	/* ��DMA1ʱ�� */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	
	/* DMA1ͨ��1���� ----------------------------------------------*/
  DMA_DeInit(DMA1_Channel1);
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)ADCConvertedValue;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = NumADC_CH*NumADC_Data;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//�ڴ��ַ����
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
  
  /* ����DMA1ͨ��1 */
  DMA_Cmd(DMA1_Channel1, ENABLE);
}
/**********************************************/
/* �������ܣ�ADC1ͨ����ʼ������										*/
/* ��ڲ�������	 	      											*/
/**********************************************/
void ADC1_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	ADC_InitTypeDef ADC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	/* ����PC40--5Ϊģ������ģʽ(ADCͨ��10--15) ---------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* ADCCLK = PCLK2/8 = 9M*/
  RCC_ADCCLKConfig(RCC_PCLK2_Div8); 
	/* ����ADC1ʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	
	/* ADC1���� ------------------------------------------------------*/
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = NumADC_CH;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1ͨ��14���� */ 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 3, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 4, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 5, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_15, 6, ADC_SampleTime_55Cycles5);	
	
  /* ʹ��ADC1 */
  ADC_Cmd(ADC1, ENABLE);
	
	/* ����ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);

  /* ʹ��ADC1��λУ׼�Ĵ��� */   
  ADC_ResetCalibration(ADC1);
  /* ���ADC1��λУ׼�Ĵ������� */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* ADC1��ʼУ׼ */
  ADC_StartCalibration(ADC1);
  /* ���ADC1У׼���� */
  while(ADC_GetCalibrationStatus(ADC1));
     
  /* ����ADC1ת�� */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}




///*��ֵ�˲�*/
//uint16_t ADC_ConvertedValue(uint16_t Number)
//{
//	uint8_t i;
//	uint16_t ADC_Value[NumADC_CH];
//	if (Number==10)
//	{
//		for(i = 0; i<NumADC_Data*NumADC_CH; i=i+NumADC_CH)
//		{
//			ADC_Value[0] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[0];
//  }
//	if (Number==11)
//	{
//		for(i = 1; i<NumADC_Data; i=i+NumADC_CH)
//		{
//			ADC_Value[1] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[1];
//  }
//	if (Number==12)
//	{
//		for(i = 2; i<NumADC_Data; i=i+NumADC_CH)
//		{
//			ADC_Value[2] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[2];
//  }
//	if (Number==13)
//	{
//		for(i = 3; i<NumADC_Data; i=i+NumADC_CH)
//		{
//			ADC_Value[3] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[3];
//  }
//	if (Number==14)
//	{
//		for(i = 4; i<NumADC_Data; i=i+NumADC_CH)
//		{
//			ADC_Value[4] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[4];
//  }
//		if (Number==15)
//	{
//		for(i = 5; i<NumADC_Data; i=i+NumADC_CH)
//		{
//			ADC_Value[5] += ADCConvertedValue[i]/NumADC_Data;
//		}
//		return ADC_Value[5];
//  }
//	
//	return 0;
//}
//	

