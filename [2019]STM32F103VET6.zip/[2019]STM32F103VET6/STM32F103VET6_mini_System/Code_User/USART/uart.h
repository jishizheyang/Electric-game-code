#ifndef __UART_H
#define __UART_H


#include "stm32f10x.h"
#include <stdio.h>


void USART1_Init(void);
void USART1_Send_byte(uint8_t val);
uint8_t USART1_Recv_byte(void);

void USART2_Init(void);
void USART2_Send_byte(uint8_t val);
uint8_t USART2_Recv_byte(void);

void USART3_Init(void);
void USART3_Send_byte(uint8_t val);
uint8_t USART3_Recv_byte(void);

#endif



