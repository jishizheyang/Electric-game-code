#ifndef _TIM_H
#define _TIM_H

#include "stm32f10x_conf.h"

void Isr_Init(void);
void Timer2_init(uint32_t freq ,uint16_t psc);
void Timer3_init(uint16_t freq ,uint16_t psc);	
void Timer4_init(uint16_t freq ,uint16_t psc);
void Timer5_init(uint16_t freq ,uint16_t psc);
void TIM5_Cap_Init(u16 arr,u16 psc);
void TIM1_PWM_Init(float freq ,uint16_t psc);
void TIM3_PWM_Init(float freq ,uint16_t psc);

typedef struct
{
	uint16_t freq;                     //Ƶ��
	float Duty_1;                   //TIM1_1ռ�ձ�
	float Duty_2;                   //TIM1_2ռ�ձ�
	float Duty_3;                   //TIM1_3ռ�ձ�
	float Duty_4;                   //TIM1_4ռ�ձ�
}PWM_TypeDef;
extern PWM_TypeDef PWM;
#endif
//end of file
