#ifndef _TIM_H
#define _TIM_H

#include "stm32f10x_conf.h"

typedef struct
{
	float Duty1;                     //ͨ��һռ�ձ�
	float Duty2;                     //ͨ����ռ�ձ�
	float Duty3;                     //ͨ����ռ�ձ�
	uint16_t TimerPerios;            //��������
	
}PWM_TypeDef;
extern PWM_TypeDef PWM;


void Isr_Init(void);
void Timer3_init(uint16_t freq ,uint8_t psc);	
void Timer4_init(uint16_t freq ,uint8_t psc);
void TIM1_PWM_Init(uint32_t freq ,uint8_t psc);
#endif
//end of file
