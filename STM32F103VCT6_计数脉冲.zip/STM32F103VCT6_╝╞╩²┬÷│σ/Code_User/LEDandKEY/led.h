#ifndef __LED_H
#define __LED_H

//#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#define LED1_ON GPIO_ResetBits(GPIOE,GPIO_Pin_4)
#define LED1_OFF GPIO_SetBits(GPIOE,GPIO_Pin_4)

#define LED2_ON GPIO_ResetBits(GPIOE,GPIO_Pin_5)
#define LED2_OFF GPIO_SetBits(GPIOE,GPIO_Pin_5)

#define LED_Toggle_PE4 GPIO_TogglePin(GPIOE,GPIO_Pin_4)
#define LED_Toggle_PE5 GPIO_TogglePin(GPIOE,GPIO_Pin_5)


//********************************************************
void LED_Init(void);		// PB5��PD12��Ϊ���������
void GPIO_TogglePin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void Flash_LED(void);

#endif	/* __LED_H */
