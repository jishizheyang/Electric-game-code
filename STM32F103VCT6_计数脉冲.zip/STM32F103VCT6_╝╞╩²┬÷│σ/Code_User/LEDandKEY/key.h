#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x_conf.h"

	
//********************************************************
void KEY_Initial(void);//key1 pc13 key2 pd3
void Fcn_Key(void);
void delay_ns(u32 ntimer);
extern uint8_t flag_start;
#endif	/* __LED_H */
