#ifndef __USART_H__
#define __USART_H__
#include <reg52.h>
#define uint32_t unsigned long
#define uint16_t unsigned int
#define int16_t  int
#define uint8_t unsigned char


sbit LED_0=P0^0;
void Usart_Int(uint32_t BaudRatePrescaler);
void USART_send_byte(uint8_t Tx_data);
void send_out(int16_t *Data,uint8_t length,uint8_t send);
void CHeck(uint8_t *re_data);
extern uint8_t KEY,read_key,stata_reg,send_ok, Receive_ok,RX_BUF[20];

#endif