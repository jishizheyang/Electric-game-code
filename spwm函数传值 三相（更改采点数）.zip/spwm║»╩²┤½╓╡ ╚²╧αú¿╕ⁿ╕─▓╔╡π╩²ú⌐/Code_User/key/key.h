#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x_conf.h"

	
//********************************************************
void KEY_Initial(void);//key1 pc13 key2 pd3
void Fcn_Key(void);

#endif	/* __LED_H */
