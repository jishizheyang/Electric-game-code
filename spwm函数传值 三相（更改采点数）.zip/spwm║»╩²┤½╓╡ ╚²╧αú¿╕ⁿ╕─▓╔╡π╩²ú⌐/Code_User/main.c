#include "stm32f10x.h"
#include "ili9341.h"
#include "delay.h"
#include "bsp_AdvanceTim.h" 
#include "spwm.h"
#include "key.h"

spwm_TypeDef spwm;

int main(void)
{		
	delay_init(72);	     //��ʱ��ʼ��
	ILI9341_Iint();
	BASIC_TIM_NVIC_Config();
	spwm.OutSinFreq = 50;
	LCD_ShowString(0,24,"Freq:",24);
	SPWM_Init();
	KEY_Initial();
	while(1)
	{		
		Fcn_Key();
		Float_Num_show(0,60,spwm.OutSinFreq,24);
	}
	}

	

/**********************************************/
/* �������ܣ���ʱ���жϷ�����*/
/* ��ڲ�������	 	      											*/
/**********************************************/

void TIM5_IRQHandler() 
{					    
	if (TIM_GetFlagStatus(TIM5, TIM_IT_Update) == SET)
	{   
		SPWM_Out();
		TIM_ClearFlag(TIM5, TIM_IT_Update);
	}
}


