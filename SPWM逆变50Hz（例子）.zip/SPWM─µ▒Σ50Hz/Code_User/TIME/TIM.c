#include "TIM.h"

void Isr_Init()
{
	NVIC_InitTypeDef NVIC_InitStructure; 
	// TIM5_IRQChannel; 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel =TIM5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init (&NVIC_InitStructure); 
}


void Timer5_init(uint16_t freq ,uint8_t psc)	
{	 
	uint16_t TimerPerio;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	RCC_APB1PeriphClockCmd (RCC_APB1Periph_TIM5,ENABLE);
	
	TimerPerio = SystemCoreClock / psc / freq;
	
	TIM_TimeBaseStructure.TIM_Period = TimerPerio-1; //��������     
	TIM_TimeBaseStructure.TIM_Prescaler =psc-1;//��Ƶֵ   	    
	TIM_TimeBaseStructure.TIM_ClockDivision = 0x0; 	//�ָ�ʱ��			
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //���ϼ���
	TIM_DeInit(TIM5);
	TIM_TimeBaseInit(TIM5, & TIM_TimeBaseStructure); 
	TIM_Cmd(TIM5, ENABLE); 	 //ʹ�ܶ�ʱ��5

	/*���¶�ʱ��5�жϳ�ʼ��*/
	TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE); //���ϼ�����������ж�
}
 

uint16_t Channel1Pulse = 0;          
uint16_t Channel2Pulse = 0;
uint16_t Channel3Pulse = 0;
uint16_t Channel4Pulse = 0;

void TIM1_PWM_Init(uint32_t freq ,uint8_t psc)          
{  
	uint16_t TimerPerio;   //�Զ���װ��Ƶ��
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;      
	TIM_OCInitTypeDef TIM_OCInitStructure;          
	TIM_BDTRInitTypeDef TIM_BDTRInitStructure;      

	TimerPerio = (SystemCoreClock / psc / freq);           
	Channel1Pulse = TimerPerio/2;
	Channel2Pulse = TimerPerio/2;
	Channel3Pulse = TimerPerio/2;
	Channel4Pulse = TimerPerio/2;

	
	
	/* TIM1,GPIOA,GPIOB*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);    
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE); 

	/*channel1,channel2,channel3,channel4 --> PA.8,PA.9,PA.10,PA.11*
	*channel1N,channel2N,channel2N --> PB.13,PB.14,PB.15*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 |GPIO_Pin_9 | GPIO_Pin_10| GPIO_Pin_11;   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //�����������                                
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);           //��ʼ��GPIOA

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 |GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure); //��ʼ��GPIOB

	/*  ???TIM1  */
	TIM_TimeBaseStructure.TIM_Period            = TimerPerio-1;   		 // ������װ������ֵ      
	TIM_TimeBaseStructure.TIM_Prescaler         = psc-1;        			 //����Ԥ��Ƶֵ          
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0;          				 //ʱ�ӷ�Ƶ          
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up;  //TIM���ϼ��� 
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;   								 //�ظ�����ж�                 
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);     							 //��ʼ����ʱ��                

	/* Channel_1   TIM_OCMode_PWM2ģʽ */ 
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM2;  //////////          
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;  //�Ƚ����ʹ��    
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //PWM���������ʹ��    
	TIM_OCInitStructure.TIM_Pulse        = Channel1Pulse;        //ռ�ձ�����       
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_Low;  //��Ч��ƽΪ��     
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_Low;  //�����෴     
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;   //�������״̬      
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;//PWM�����������״̬      
	TIM_OC1Init(TIM1, &TIM_OCInitStructure); //��ʼ������TIM1 OC1

  /* Channel_2      TIM_OCMode_PWM1ģʽ */  
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM2;   ///////         
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;    
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;     
	TIM_OCInitStructure.TIM_Pulse        = Channel2Pulse;               
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_Low;         
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_Low;        
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;         
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;     
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);                            

	/* Channel_3      TIM_OCMode_PWM1ģʽ */  
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM2;            
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;      
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;     
	TIM_OCInitStructure.TIM_Pulse        = Channel3Pulse;               
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;         
	TIM_OCInitStructure.TIM_OCNPolarity  = TIM_OCNPolarity_High;        
	TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Set;         
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;      
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);                            

  /* Channel_4      TIM_OCMode_PWM1ģʽ */ 
  TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM2;            
	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;          
	TIM_OCInitStructure.TIM_Pulse        = Channel4Pulse;               
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;              
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);  
	
	
	
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);//ʹ��TIM1��CCR1�ϵ�Ԥװ�ؼĴ���
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);                  
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);                   
  TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);  

	/*������ɲ����������*/
	TIM_BDTRInitStructure.TIM_OSSRState       = TIM_OSSRState_Enable;
	TIM_BDTRInitStructure.TIM_OSSIState       = TIM_OSSIState_Enable;
	TIM_BDTRInitStructure.TIM_LOCKLevel       = TIM_LOCKLevel_1;
	TIM_BDTRInitStructure.TIM_DeadTime        = 0x10;                   //����TIM1_BDTR��DTG������ʱ��DTG[7:0]
	TIM_BDTRInitStructure.TIM_Break           = TIM_Break_Disable;
	TIM_BDTRInitStructure.TIM_BreakPolarity   = TIM_BreakPolarity_High;
	TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM1, &TIM_BDTRInitStructure);

	TIM_Cmd(TIM1, ENABLE);          //ʹ��TIM1                                     
	TIM_CtrlPWMOutputs(TIM1,ENABLE); //PWM���ʹ��                                  
}

//end of file
