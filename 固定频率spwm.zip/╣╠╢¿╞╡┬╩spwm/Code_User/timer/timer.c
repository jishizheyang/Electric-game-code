#include "timer.h"
#include "led.h"



void TIM3_Int_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStructrue;
  RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM3, ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM3, & TIM_TimeBaseInitStruct);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	NVIC_InitStructrue.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitStructrue.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructrue.NVIC_IRQChannelSubPriority=3;
	NVIC_InitStructrue.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructrue);
	TIM_Cmd(TIM3, ENABLE);
}

void TIM3_IRQHandler(void)
{

	if(TIM_GetITStatus(TIM3, TIM_IT_Update)!=RESET)
	{
		GPIO_TogglePin(GPIOB,GPIO_Pin_5);
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
	
}

