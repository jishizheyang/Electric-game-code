#include "spwm.h"
#include "TIM1PWM.h"
#include "math.h"
#include "ili9341.h"

#define K 400


void SPWM_Init(void)
{   
	uint16_t i;                                             //����
	spwm.InsquareFreq = K * spwm.OutSinFreq;              //���Ʒ�������Ƶ��
	spwm.Duty = 72000000/spwm.InsquareFreq/2;               //��������
	for(i = 0; i < K; i++)
	{
		spwm.table_399_a[i] = spwm.Duty *(1+sin((float)i/K*6.28));
	}
	spwm.SinTab_i = 0;
	
	JX_TIM1_PWM_Init(spwm.InsquareFreq,1);                    //pwm����Ƶ��spwm.OutSinFreq(30-100Hz)     	       
	Timer5_init(spwm.InsquareFreq,1);
}



void SPWM_Out(void)
{
	TIM1 -> CCR1 = spwm.table_399_a[spwm.SinTab_i];
  TIM1 -> CCR2 = spwm.table_399_a[spwm.SinTab_i];  
	spwm.SinTab_i++;
	if(spwm.SinTab_i == K )                       //�ж��Ƿ���һ������
	{
		spwm.SinTab_i = 0;
	}
}
