#ifndef __TIM1PWM_H
#define __TIM1PWM_H

#include "stm32f10x.h"



void NVIC_Config_PWM(void);
void JX_TIM1_PWM_Init(uint32_t freq ,uint8_t psc);
void Timer5_init(uint16_t freq ,uint8_t psc);	



#endif

