#include "pid.h"
#include "led.h"
#include "ili9341.h"
#include "TIM.h"
#include "adc_dma.h"


/*����ʽPID�㷨*/
PIDTypeStruct pid;
float MeasureU,MeasureI,MeasureP;
float SetDuty = 1;
u8 flagU,flagI;

/*===========user_code===========*/
void PID_Init(void)
{
	pid.ErrK[0] = 0;              //��ʼ������Ϊ0
	pid.ErrK[1] = 0;
	pid.ErrK[2] = 0;
	pid.PeriodT = 1;						  //��������ms
	pid.Kp = 4;//3;
	pid.Ti = 3;//8.5;
	pid.Td = 1;//1.2;
	pid.Ki = pid.Kp*pid.PeriodT/pid.Ti;
	pid.Kd = pid.Kp * pid.Td/pid.PeriodT;
}

void PID_Calc(void)
{
	pid.ErrK[0]  = pid.ErrK[1];		//��ֵ������λ��ע�ⲻҪ���ݸ���
	pid.ErrK[1]  = pid.ErrK[2];
	
	MeasureU = Get_Adc_average(0,5)*(3.300/4095)*11.5;		//����ѹ������*(3.300/4095)
	MeasureI = Get_Adc_average(1,5)*(3.300/4095)*5.4054-13.5135;
	MeasureP = MeasureU * MeasureI;
	Float_Num_show(0,50,MeasureU,24);
	Float_Num_show(0,100,MeasureI,24);
	Float_Num_show(0,150,MeasureU,24);
	
	if(flagU == 1)
	{
		SetDuty = 12;
		pid.CurrDuty = MeasureU;// + 0.8;
	}
	if(flagI == 1)
	{
		SetDuty = 1;
		pid.CurrDuty = MeasureI + 0.3;//current measure offset
	}
	
	pid.ErrK[2] = SetDuty - pid.CurrDuty;
	if(pid.ErrK[2] > 0.05 | pid.ErrK[2] < (-0.05))
	{
		pid.Pout = pid.Kp * (pid.ErrK[2]- pid.ErrK[1]);
		pid.Iout = pid.Ki * pid.ErrK[2];
		pid.Dout = pid.Kd * (pid.ErrK[2] - 2 * pid.ErrK[1] + pid.ErrK[0]);
		pid.AssUK= pid.Pout+pid.Iout+pid.Dout;
		
		TIM8->CCR1 += (pid.AssUK);
		if(TIM8->CCR1 < PidMin)													//��ѹ��������
		{
			TIM8->CCR1 = PidMin;
		}
		else if(TIM8->CCR1 > PidMax)
		{
			TIM8->CCR1 = PidMax;
		}
		Float_Num_show(66,225,pid.AssUK,24);
		LCD_ShowNum(66,250,TIM8->CCR1,24);
		GPIO_TogglePin(GPIOB, GPIO_Pin_5);
	}
	Float_Num_show(120,250,pid.ErrK[2],16);
	Float_Num_show(50,0,SetDuty,24);
}






//end of file
