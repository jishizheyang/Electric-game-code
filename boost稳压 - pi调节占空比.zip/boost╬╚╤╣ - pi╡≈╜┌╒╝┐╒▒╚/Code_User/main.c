#include "stm32f10x.h"
#include "delay.h"
#include "ili9341.h"
#include "led.h"
#include "stdio.h"
#include "TIM.h"
#include "adc_dma.h"
#include "pid.h"
#include "pi.h"
#include "key.h"

/*  Founcational Prototype  */

uint8_t Metering = 0;						//�жϼƴ�
extern PIDTypeStruct pid;
extern float SetDuty;
int	flag;
extern float MeasureU,MeasureI,MeasureP;
float Resister;


int main(void)
{
	LED_Init_JX();
	delay_init(72);
	ILI9341_Iint();
	JX_ADC_DMA_Init();												//ADC DMA�����ʼ��
	JX_ADC1_CH14ANDCH15_Init();								//ADC1 ͨ��14 15��ʼ��
	Timer3_init(1000,72);											
	Isr_Init();																//�жϳ�ʼ��
	TIM1_PWM_Init(20000,1);										
	PI_Init();  
  KEY_Init();
	flag=0;
	
	while(1)
	{
		LCD_ShowString(0,0,"Set",24);
		LCD_ShowString(0,25,"Measure U",24);
		MeasureU = Get_Adc_average(0,5)*(3.300/4095)*10;           //�ɻ����ĵ�ѹֵ 

		if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)==0)	// ˵��key1���� ��ʱled1��
			{
				
				delay_ms(2);
				if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == RESET)
				{
					while(GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_13 ) == RESET);
				flag=1;
				
				}
			}
		if(flag == 1)
		{
			PI_Calc();
			GPIO_TogglePin(GPIOD,GPIO_Pin_12);
		}
	}
}





/*===========================================*/
/*user code*/


/*��ʱ��3�жϷ�����*/

 void TIM3_IRQHandler()
{					  
	if (TIM_GetFlagStatus(TIM3, TIM_IT_Update) == SET)
	{

		TIM_ClearFlag(TIM3, TIM_IT_Update);
	}
}


/*��ʱ��4�жϷ�����*/
void TIM4_IRQHandler()
{					    
	if (TIM_GetFlagStatus(TIM4, TIM_IT_Update) == SET)
	{
		
		//add your code
		TIM_ClearFlag(TIM4, TIM_IT_Update);
	}
}



