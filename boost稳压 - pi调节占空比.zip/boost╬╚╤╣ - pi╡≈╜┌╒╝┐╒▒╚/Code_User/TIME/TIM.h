#ifndef _TIM_H
#define _TIM_H

#include "stm32f10x_conf.h"

void Isr_Init(void);
void Timer3_init(uint16_t freq ,uint8_t psc);	
void Timer4_init(uint16_t freq ,uint8_t psc);
void TIM8_PWM_Init(uint32_t freq ,uint8_t psc);
void TIM1_PWM_Init(uint32_t freq ,uint8_t psc);
#endif
//end of file
