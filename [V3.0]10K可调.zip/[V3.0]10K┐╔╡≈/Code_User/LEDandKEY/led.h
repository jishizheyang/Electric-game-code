#ifndef __LED_H
#define __LED_H

//#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#define LED1_ON GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define LED1_OFF GPIO_SetBits(GPIOB,GPIO_Pin_5)

#define LED2_ON GPIO_ResetBits(GPIOC,GPIO_Pin_13)
#define LED2_OFF GPIO_SetBits(GPIOC,GPIO_Pin_13)

#define LED_Toggle_PB5 GPIO_TogglePin(GPIOB,GPIO_Pin_5)

#define LED_Toggle_PC6 GPIO_TogglePin(GPIOC,GPIO_Pin_6)
#define LED_Toggle_PC7 GPIO_TogglePin(GPIOC,GPIO_Pin_7)
#define LED_Toggle_PC8 GPIO_TogglePin(GPIOC,GPIO_Pin_8)
#define LED_Toggle_PC9 GPIO_TogglePin(GPIOC,GPIO_Pin_9)
#define LED_Toggle_PC10 GPIO_TogglePin(GPIOC,GPIO_Pin_10)
#define LED_Toggle_PC11 GPIO_TogglePin(GPIOC,GPIO_Pin_11)
#define LED_Toggle_PC12 GPIO_TogglePin(GPIOC,GPIO_Pin_12)
#define LED_Toggle_PC13 GPIO_TogglePin(GPIOC,GPIO_Pin_13)


//********************************************************
void LED_Init(void);		// PB5��PD12��Ϊ���������
void GPIO_TogglePin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void Flash_LED(void);

#endif	/* __LED_H */
