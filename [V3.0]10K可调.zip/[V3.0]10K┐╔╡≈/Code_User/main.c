#include "stm32f10x.h"
#include "ili9341.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "TIM.h"
#include "stdio.h"

#define ADC1_DR_Address    ((uint32_t)0x4001244C)
//#define Freq 10000
#define PSC 8 
#define NumADC_CH 6
#define NumADC_Data 11

__IO uint16_t ADCConvertedValue[NumADC_CH*NumADC_Data]; // ����һ��16λ������ ������ADCת����ֵ
void ADC_DMA_Init(void);
void ADC1_Init(void);
PWM_TypeDef pwm;


// ������
int main(void)
{
	pwm.Freq = 10000;
	pwm.FreqStep = 1000;
	LED_Init();
	delay_init(72);	     //��ʱ��ʼ��
	ILI9341_Iint();
//	Timer4_init(100,72);		//10ms�ж�һ��
	TIM1_PWM_Init(pwm.Freq,PSC);	//	pwm����Ƶ��1.6kHz
//	ADC_DMA_Init();  // DMA��ʼ������
//	ADC1_Init(); // ��ʼ��ADC1
	Isr_Init();

	KEY_Initial();
//	Timer3_init(50,72);//20ms
	LCD_ShowString(100,0,"Hello",24);
	LCD_ShowString(0,24,"Freq:",24);
	LCD_ShowString(0,48,"Duty:",24);

	while(1)
	{
		Float_Num_show(100,24,pwm.Freq,24);
		Float_Num_show(100,48,pwm.Duty_1,24);
		  Fcn_Key();
	}
}



/**********************************************/
/* �������ܣ�DMA��ʼ������										*/
/* ��ڲ�������	 	      											*/
/**********************************************/
void ADC_DMA_Init(void)
{
	DMA_InitTypeDef DMA_InitStructure;
	
	/* ��DMA1ʱ�� */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	
	/* DMA1ͨ��1���� ----------------------------------------------*/
  DMA_DeInit(DMA1_Channel1);
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)ADCConvertedValue;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = NumADC_CH*NumADC_Data;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//�ڴ��ַ����
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
  
  /* ����DMA1ͨ��1 */
  DMA_Cmd(DMA1_Channel1, ENABLE);
}
/**********************************************/
/* �������ܣ�ADC1ͨ����ʼ������										*/
/* ��ڲ�������	 	      											*/
/**********************************************/
void ADC1_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	ADC_InitTypeDef ADC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	/* ����PC40--5Ϊģ������ģʽ(ADCͨ��10--15) ---------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* ADCCLK = PCLK2/8 = 9M*/
  RCC_ADCCLKConfig(RCC_PCLK2_Div8); 
	/* ����ADC1ʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	
	/* ADC1���� ------------------------------------------------------*/
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 6;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1ͨ��14���� */ 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 3, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 4, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 5, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_15, 6, ADC_SampleTime_55Cycles5);	
	
  /* ʹ��ADC1 */
  ADC_Cmd(ADC1, ENABLE);
	
	/* ����ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);

  /* ʹ��ADC1��λУ׼�Ĵ��� */   
  ADC_ResetCalibration(ADC1);
  /* ���ADC1��λУ׼�Ĵ������� */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* ADC1��ʼУ׼ */
  ADC_StartCalibration(ADC1);
  /* ���ADC1У׼���� */
  while(ADC_GetCalibrationStatus(ADC1));
     
  /* ����ADC1ת�� */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
/**********************************************/
/* �������ܣ���ʱ���жϷ�����*/
/* ��ڲ�������	 	      											*/
/**********************************************/
void TIM4_IRQHandler() //1ms 1��
{					    
	if (TIM_GetFlagStatus(TIM4, TIM_IT_Update) == SET)
	{   
//		LED_Toggle_PB5;
		TIM_ClearFlag(TIM4, TIM_IT_Update);
	}
}

 void TIM3_IRQHandler() 
{					  
	if (TIM_GetFlagStatus(TIM3, TIM_IT_Update) == SET)
	{  	

		TIM_ClearFlag(TIM3, TIM_IT_Update);
	}
}
//end of file
